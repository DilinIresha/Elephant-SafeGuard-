module.exports.permissions = {
  saveData: {
    path: "/",
  },
  getData: {
    path: "/",
  },
  getALReportData: {
    path: "/get-report-data",
  },
};
